package com.itheima.demo.mapper;

import com.itheima.demo.bean.LockRecord;
import tk.mybatis.mapper.common.Mapper;

public interface LockRecordMapper extends Mapper<LockRecord> {
}
