package com.itheim.dubbo;


public class BootProviderApplication {

    public static void main(String[] args) {

    }

}
