package com.itheima.spi;

import org.apache.dubbo.common.extension.SPI;

@SPI
public interface Czbk {

    void service();
}
