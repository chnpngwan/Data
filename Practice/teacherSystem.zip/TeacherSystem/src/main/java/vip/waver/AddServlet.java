package vip.waver;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/add")
public class AddServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, 
			HttpServletResponse resp) throws ServletException, IOException {
		
		String name = req.getParameter("name");
		String sex = req.getParameter("sex");
		int age = Integer.parseInt(req.getParameter("age"));
		String position = req.getParameter("position");
		Teacher t = new Teacher(0, name, sex, age, position);
		JDBCUtil.addATeacher(t);
		
		resp.sendRedirect("list");
	}

}
