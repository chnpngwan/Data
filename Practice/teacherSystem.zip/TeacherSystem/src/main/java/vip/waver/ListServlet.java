package vip.waver;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/list")
public class ListServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, 
			HttpServletResponse resp) throws ServletException, IOException {
		
		// 1. 跟JDBC拿到数据：所有的教师信息;
		List<Teacher> list = JDBCUtil.getAllTeachers();
		// 2. 将数据传递给Jsp
		req.setAttribute("a", list);
		req.getRequestDispatcher("list.jsp").forward(req, resp);
		
	}

	
}
