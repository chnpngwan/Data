package vip.waver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JDBCUtil {
	
	public static String url = "jdbc:mysql://localhost:3306/teacher_system";
	public static String username = "root";
	public static String password = "123456";
	

	// 对内
	// 1. 加载驱动(静态代码块)
	static {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	// 2. 获取连接
	public static Connection getConnection() {
		
		try {
			Connection conn =  DriverManager.getConnection(
					url,
					username, 
					password);
			
			return conn;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	// 对外
	// 权限 非权限 返回值 方法名(参数列表) {}
	// 1. 获取所有的教师信息
	public static List<Teacher> getAllTeachers() {
		
		// 目标sql
		String sql = "select * from teacher;";
		// 目标Connection，getConnection()
		Connection conn = getConnection();
		try {
			// 目标Statement，Connection.preparedStatement(sql)
			PreparedStatement state = conn.prepareStatement(sql);
			// 目标ResultSet，通过Statement.executeQuery()
			ResultSet result = state.executeQuery();
			// 目标List，通过ResultSet
			List<Teacher> list = new ArrayList<Teacher>();
			while(result.next()) {
				
				int id = result.getInt("id");
				String name = result.getString("name");
				String sex = result.getString("sex");
				int age = result.getInt("age");
				String position = result.getString("position");
				// 讲一个老师的所有信息，组装成一个Teacher对象
				Teacher t = new Teacher(id, name, sex, age, position);
				list.add(t);
			}
			
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	// 2. 删除某一个教师
	public static void deleteATeacher(int id) {
		
		// 目标sql
		String sql = "delete from teacher where id="
				+ id
				+ ";";
		System.out.println(sql);
		// 目标Connection，getConnection()
		Connection conn = getConnection();
		
		// 目标Statement，Connection.preparedStatement(sql)
		PreparedStatement state;
		try {
			state = conn.prepareStatement(sql);
			// 目标ResultSet，通过Statement.executeUpdate()
			state.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	
	// 3. 添加一个教师
	public static void addATeacher(Teacher teacher) {
		// 目标sql
		String sql = "insert into teacher(name, sex, age, position) "
				+ "values("
				+ "'"
				+ teacher.getName()
				+ "'"
				+ ", "
				+ "'"
				+ teacher.getSex()
				+ "'"
				+ ", "
				+ teacher.getAge()
				+ ", "
				+ "'"
				+ teacher.getPosition()
				+ "'"
				+ ");";
		System.out.println(sql);
		// 目标Connection，getConnection()
		Connection conn = getConnection();
		// 目标Statement，Connection.preparedStatement(sql)
		PreparedStatement state;
		try {
			state = conn.prepareStatement(sql);
			// 目标ResultSet，通过Statement.executeUpdate()
			state.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// 4. 获取符合条件的教师信息
	public static List<Teacher> getSomeTeachers(String keyword) {
		
		// 目标sql
		String sql = "select * from teacher where name like '%"
				+ keyword
				+ "%';";
		System.out.println(sql);
		// 目标Connection，getConnection()
		Connection conn = getConnection();
		try {
			// 目标Statement，Connection.preparedStatement(sql)
			PreparedStatement state = conn.prepareStatement(sql);
			// 目标ResultSet，通过Statement.executeQuery()
			ResultSet result = state.executeQuery();
			// 目标List，通过ResultSet
			List<Teacher> list = new ArrayList<Teacher>();
			while(result.next()) {
				
				int id = result.getInt("id");
				String name = result.getString("name");
				String sex = result.getString("sex");
				int age = result.getInt("age");
				String position = result.getString("position");
				// 讲一个老师的所有信息，组装成一个Teacher对象
				Teacher t = new Teacher(id, name, sex, age, position);
				list.add(t);
			}
			
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	// 5. 修改一个教师
	public static void updateATeacher(Teacher teacher) {
		// 目标sql
		String sql = "update teacher set name="
				+ "'"
				+ teacher.getName()
				+ "'"
				+ ",sex="
				+ "'"
				+ teacher.getSex()
				+ "'"
				+ ",age="
				+ teacher.getAge()
				+ ",position="
				+ "'"
				+ teacher.getPosition()
				+ "'"
				+ " where id="
				+ teacher.getId()
				+ ";";
		System.out.println(sql);
		// 目标Connection，getConnection()
		Connection conn = getConnection();
		// 目标Statement，Connection.preparedStatement(sql)
		PreparedStatement state;
		try {
			state = conn.prepareStatement(sql);
			// 目标ResultSet，通过Statement.executeUpdate()
			state.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
