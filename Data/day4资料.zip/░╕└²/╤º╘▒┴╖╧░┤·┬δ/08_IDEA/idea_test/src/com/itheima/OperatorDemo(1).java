package com.itheima;

/*
    快速生成语句
	    快速生成main()方法：psvm，回车
	    快速生成输出语句：sout，回车

    内容辅助键
	    Ctrl+Alt+space(内容提示，代码补全等)

    快捷键：
       	注释：
       	    单行：选中代码，Ctrl+/，再来一次，就是取消
            多行：选中代码，Ctrl+Shift+/，再来一次，就是取消

        格式化
	        Ctrl+Alt+L
 */
public class OperatorDemo {
    
}
